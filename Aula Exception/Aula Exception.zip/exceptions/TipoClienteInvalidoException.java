package exceptions;

public class TipoClienteInvalidoException extends RuntimeException {
    public TipoClienteInvalidoException(String message) {
        super(message);
    }
}
